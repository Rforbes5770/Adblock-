Dear Sir/Madam,

If you have any problems with our product please, feel free to contact us. 
Our email is: support@chromeextensioncreator.com

Also you can find some useful information on the product's official site: http://chromeextensioncreator.com

-----------------------------

Best regards, ToolbarDev Team

http://toolbardev.com
