CRX_DIRECTORY = 'crawled/crx/'
PAGES_DIRECTORY = 'crawled/pages/'
SITEMAP_FILE = 'data/sitemap.json'

# These extensions owners have requested that their
# extensions source code shall not be published :(

BLACKLIST = [
    "edacconmaakjimmfgnblocblbcdcpbko", # Session Buddy
    "adpjkecnjfmgneijfljandenedleocdo", # ixigo inspire
]
